using Volo.Abp.Caching;
using Volo.Abp.Domain;
using Volo.Abp.Modularity;
using Test.Domain.Shared;
using Yi.Framework.AuditLogging.Domain;
using Yi.Framework.Bbs.Domain;
using Yi.Framework.ChatHub.Domain;
using Yi.Framework.Mapster;
using Yi.Framework.Rbac.Domain;
using Yi.Framework.TenantManagement.Domain;

namespace Test.Domain
{
    [DependsOn(
        typeof(TestDomainSharedModule),
       
        typeof(YiFrameworkTenantManagementDomainModule),
        typeof(YiFrameworkRbacDomainModule),
        typeof(YiFrameworkBbsDomainModule),
        typeof(YiFrameworkChatHubDomainModule),
        typeof(YiFrameworkAuditLoggingDomainModule),

        typeof(YiFrameworkMapsterModule),
        typeof(AbpDddDomainModule),
        typeof(AbpCachingModule)
        )]
    public class TestDomainModule : AbpModule
    {

    }
}