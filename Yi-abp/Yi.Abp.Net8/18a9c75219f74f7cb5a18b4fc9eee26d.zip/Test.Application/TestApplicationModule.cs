using Test.Application.Contracts;
using Test.Domain;
using Yi.Framework.Bbs.Application;
using Yi.Framework.ChatHub.Application;
using Yi.Framework.CodeGen.Application;
using Yi.Framework.Ddd.Application;
using Yi.Framework.Rbac.Application;
using Yi.Framework.TenantManagement.Application;

namespace Test.Application
{
    [DependsOn(
        typeof(TestApplicationContractsModule),
        typeof(TestDomainModule),


        typeof(YiFrameworkRbacApplicationModule),
         typeof(YiFrameworkBbsApplicationModule),
         typeof(YiFrameworkChatHubApplicationModule),
        typeof(YiFrameworkTenantManagementApplicationModule),
        typeof(YiFrameworkCodeGenApplicationModule),

        typeof(YiFrameworkDddApplicationModule)
        )]
    public class TestApplicationModule : AbpModule
    {
    }
}
